package mx.edu.utez.viba22;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Viba22ApplicationTests {

	@Test
	void contextLoads() {
	}

}
