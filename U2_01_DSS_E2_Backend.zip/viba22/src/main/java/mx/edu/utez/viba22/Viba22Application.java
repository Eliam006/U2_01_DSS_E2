package mx.edu.utez.viba22;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Viba22Application {

	public static void main(String[] args) {
		SpringApplication.run(Viba22Application.class, args);
	}

}
